# [linktree](https://samirpaul1.github.io/link)
Simple site to group all my profiles on social networks in one place. A free Linktree alternative.

Landing Page:
![screenshot](https://raw.githubusercontent.com/SamirPaul1/links/main/samirpaul1-links.jpeg)
